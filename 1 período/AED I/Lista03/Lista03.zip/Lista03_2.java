import java.util.Scanner;
public class Lista03_2
{
   public static void main(String[]args)
   {
      int n=10;
      do
      {
         System.out.println(n);
         n=n-1;
      }while (n>=1);
   }
}      