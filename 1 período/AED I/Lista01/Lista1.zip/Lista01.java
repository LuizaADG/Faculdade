import java.util.Scanner;
public class Lista01
{
   public static void main(String[]args)
   {
       Scanner scanner= new Scanner(System.in);
       double lado,
              perimetro;
       lado= scanner.nextDouble();
       perimetro=4*lado;
      System.out.print(perimetro);
   }
}      
    
       