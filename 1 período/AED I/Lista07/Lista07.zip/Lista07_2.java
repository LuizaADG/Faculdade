//Nome do programa: Lista07_2 
//Data da elabora��o: 02/04/17
//Autor: Luiza
//Objetivo: Verificar aprova��o ou n�o do aluno
//Argumentos: notas, soma,aprovado,mensagem
//Valor gerado: aprova��o, total e notas 
import java.util.Scanner;
public class Lista07_2
{
   public static void main (String[]args)
   {
      double nota1,
             nota2,
             soma;
      boolean aprovado,
              mensagem;          
      apresentacao();
      nota1=leNota1();
      nota2=leNota2();
      soma=soma(nota1,nota2);  
      aprovado=aprovado(soma);
      mensagem=mensagem(aprovado);
      total(soma,nota1,nota2);
   }
   public static void apresentacao ()
   {
      System.out.println("O programa a seguir verificara se o aluno foi aprovado ou n�o");
   }
   public static double leNota1 ()
   {
      Scanner s= new Scanner(System.in);
      double n;
      do
      {
         System.out.println("Digite a 1 nota");
         n=s.nextDouble();
         if (n<0|| n>50) System.out.println("Valor Inv�lido");
      }while (n<0 || n>50);    
      return n;
   }   
   public static double leNota2 ()
   {
      Scanner s= new Scanner(System.in);
      double v;
      do
      {
         System.out.println("Digite a 2 nota");
         v=s.nextDouble();
         if (v<0|| v>50) System.out.println("Valor Inv�lido");
      }while (v<0 || v>50);    
      return v;
   }     
   public static double soma(double v, double n)
   {
      double soma=0;
      soma=v+n;
      return soma;
   }
   public static boolean aprovado(double soma)
   {
      boolean aprovado=true;
      if (soma<60)aprovado=false;
      return aprovado;
   }        
   public static boolean mensagem(boolean aprovado)
   {   
      if (aprovado)
      {
         System.out.println("O aluno foi aprovado");
      }
      else
      {
         System.out.println("O aluno n�o foi aprovado");
      }
      return aprovado;
   }      
   public static void total(double soma, double v, double n)
   {
      System.out.println("A nota total do aluno="+soma+" Pois as notas foram "+v+"e "+n);
   }
}