package academia;

/**
 * @author Luiz Guimarães                   - 602076
 * @author Luiza Ávila                      - 587490
 * @author Wisney Tadeu A A dos Santos      - 602715
 * @author Gabriel Gome da Cunha            - 587467
 */
/**
 * CRUD
 * Nosso método tem 1:N --> Uma academia pode ter N clientes;
 * Nosso método tem N:N --> 1 academia pode ter N modalidades, 1 modalidade pode ter N academias
 * Nosso método tem a classe que gera os arquivo cifrados
 * Criamos listar invertidas entre modalidade e academias.
 */
import java.util.Scanner;
import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Interface {

    private static Scanner Read = new Scanner(System.in);
    private static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    private static ArvoreBMais_Int_Long indiceAcademia;
    private static ArvoreBMais_Int_Long indiceCliente;
    private static ArvoreBMais_Int_Long indiceModalidade;
    private static ArvoreBMais_ChaveComposta indiceAcademiaCliente;
    private static ArvoreBMais_ChaveComposta indiceAcademiaModalidade;
    private static ArvoreBMais_ChaveComposta indiceModalidadeAcademia;
    private static Arquivo arquivo;

    public static void main(String[] args) {
        try {
            indiceAcademia = new ArvoreBMais_Int_Long(1000, "indiceAcademia.db");
            indiceCliente = new ArvoreBMais_Int_Long(1000, "indiceCliente.db");
            indiceModalidade = new ArvoreBMais_Int_Long(1000, "indiceModalidade.db");
            indiceAcademiaCliente = new ArvoreBMais_ChaveComposta(1000, "indiceAcademiaCliente.db");
            indiceAcademiaModalidade = new ArvoreBMais_ChaveComposta(1000, "indiceAcademiaModalidade");
            indiceModalidadeAcademia = new ArvoreBMais_ChaveComposta(1000, "indiceModalidadeAcademia.db");
        } catch (IOException ex) {
            Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
        }
        int operacao = 0;
        Menu();
        arquivo = new Arquivo();
        Modalidade modalidade = new Modalidade();
        do {
            operacao = Read.nextInt();
            switch (operacao) {
                case 0:
                    System.out.println("Obrigado por usar o programa!");
                    break;
                case 1:
                    cadastroCliente();
                    break;
                case 2:
                    arquivo.listarArq(new Cliente());
                    break;
                case 3:
                    editarCliente(new Cliente());
                    break;
                case 4:
                    deletarCliente(new Cliente());
                    break;
                case 5:
                    Menu();
                    break;
                case 6:
                    cadastroModalidade();
                    break;
                case 7:
                    arquivo.listarArq(new Modalidade());
                    break;
                case 8:
                    editarModalidades(new Modalidade());
                    break;
                case 9:
                    deletarModalidades(modalidade);
                    break;
                case 10:
                    cadastroAcademia();
                    break;
                case 11:
                    arquivo.listarArq(new Academia());
                    break;
                case 12:
                    editarAcademia(new Academia());
                    break;
                case 13:
                    deletarAcademia(new Academia());
                    break;
                case 14:
                    vincular();
                    break;
                case 15:
                    desvincular();
                    break;
                case 16:
                    pesquisa();
                    break;
            }
            if (operacao != 0) {
                System.out.println("+------------------------------------------------------------------------------+");
                System.out.println("Digite a opercao:");
            }
        } while (operacao != 0);

    }

    public static void Menu() {
        System.out.println("+----------------------------------------------------------------------------------+");
        System.out.println("|========================================== MENU ================================================|");
        System.out.println("|0 -> sair                |  6 -> Cadastrar Modalidade |  12 -> Editar Academia                  |");
        System.out.println("|1 -> Cadastrar Cliente   |  7 -> Listar Modalidade    |  13 -> Deletar Academia                 |");
        System.out.println("|2 -> Listar Clientes     |  8 -> Editar Modalidade    |  14 -> Vincular academia a modalidade   |");
        System.out.println("|3 -> Editar Clientes     |  9 -> Deletar Modalidade   |  15 -> Desvincular academia a modalidade|");
        System.out.println("|4 -> Deletar Cliente     | 10 -> Cadastrar Academia   |                                         |");
        System.out.println("|5 -> Menu                | 11 -> Listar Academia      |  16 -> Pesquisar                        |");
        System.out.println("+------------------------------------------------------------------------------------------------+");
        System.out.println("Digite a opercao:");
    }

    /**
     * @Cadastros Contém cadastro de clientes, de Academias e de Modalidades
     */
    public static void cadastroCliente() {
        Arquivo arq = new Arquivo();
        if (arq.getQuantidade(new Academia()) == 0) {
            System.out.println("Antes de cadastrar um cliente, por favor cadastre a academia");
            return;
        }
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.println("| Cadastrando Cliente:                                                         |");
        System.out.println("+------------------------------------------------------------------------------+");
        char confirmado = 'n', sexo;
        String nome, email, login, senha, logradouro, complemento, bairro, cidade, estado, pais, cep;
        long nascimento;
        int numero, academia;
        Cliente tmp;
        try {
            do {
                System.out.println("Digite o nome:");
                nome = in.readLine();
                System.out.println("Digite o e-mail:");
                email = in.readLine();
                System.out.println("Digite o sexo:(M/F)");
                sexo = (char) in.readLine().charAt(0);
                System.out.println("Digite o login:");
                login = in.readLine();
                System.out.println("Digite a senha:");
                senha = in.readLine();
                System.out.println("Digite a data de nascimento.:(dd/mm/aaaa)");
                nascimento = new Cliente().CalculaData(in.readLine());//Long.parseLong(in.readLine()) ;
                System.out.println("Digite o logradouro: ");
                logradouro = in.readLine();
                System.out.println("Digite o numero residencial:Ex.:(123)");
                numero = Integer.parseInt(in.readLine());
                System.out.println("Digite o complemento:");
                complemento = in.readLine();
                System.out.println("Digite o bairro:");
                bairro = in.readLine();
                System.out.println("Digite o CEP:");
                cep = in.readLine();
                System.out.println("Digite a cidade:");
                cidade = in.readLine();
                System.out.println("Digite o estado:");
                estado = in.readLine();
                System.out.println("Digite o pais:");
                pais = in.readLine();
                System.out.println("Digite o código da academia que o cliente pertence: ");
                academia = Integer.parseInt(in.readLine());
                System.out.println("+------------------------------------------------------------------------------+");
                System.out.println("Confirma o cadastro: \nDigite 's' para sim \nDigite 'n' para nao");
                confirmado = (char) in.readLine().charAt(0);
                if (confirmado == 'N' || confirmado == 'n') {
                    System.out.println("Deseja refazer o cadastro: \nDigite 's' para sim \nDigite 'n' para nao");
                    confirmado = (char) in.readLine().charAt(0);
                    if (confirmado == 'S' || confirmado == 's') {
                        confirmado = 'n';
                    } else {
                        confirmado = 'q';
                    }
                }
            } while ((confirmado != 's' && confirmado != 'S') || confirmado == 'q');
            if (confirmado == 'S' || confirmado == 's') {
                tmp = new Cliente(arq, nome, email, sexo, login, senha, nascimento, logradouro, numero, complemento, bairro, cep, cidade, estado, pais, academia);
                long endereco = new Arquivo().incluiArq(tmp);
                indiceCliente.inserir(tmp.getClienteID(), endereco);
                indiceAcademiaCliente.inserir(academia, tmp.getClienteID());
            }
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static void cadastroModalidade() {
        Arquivo arq = new Arquivo();
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.println("| Cadastrando Modalidade:                                                      |");
        System.out.println("+------------------------------------------------------------------------------+");
        Modalidade tmp;
        String nome, descricao, professor;
        char turno, confirmado = 'n';
        try {
            do {
                System.out.println("Digite o nome da modalidade: ");
                nome = in.readLine();
                System.out.println("Escreva a descrição da modalidade: ");
                descricao = in.readLine();
                System.out.println("Escreva o nome do professor: ");
                professor = in.readLine();
                System.out.println("Digite o turno da modalidade: (M/T/N)");
                turno = (char) in.readLine().charAt(0);
                System.out.println("Confirma o cadastro: \nDigite 's' para sim \nDigite 'n' para nao");
                confirmado = (char) in.readLine().charAt(0);
                if (confirmado == 'N' || confirmado == 'n') {
                    System.out.println("Deseja refazer o cadastro: \nDigite 's' para sim \nDigite 'n' para nao");
                    confirmado = (char) in.readLine().charAt(0);
                    if (confirmado == 'S' || confirmado == 's') {
                        confirmado = 'n';
                    } else {
                        confirmado = 'q';
                    }
                }
            } while ((confirmado != 's' && confirmado != 'S') || confirmado == 'q');
            if (confirmado == 'S' || confirmado == 's') {
                tmp = new Modalidade(arq, nome, descricao, professor, turno);
                long endereco = new Arquivo().incluiArq(tmp);
                indiceModalidade.inserir(tmp.getModalidadeID(), endereco);
            }

        } catch (Exception e) {
        }
    }

    public static void cadastroAcademia() {
        Arquivo arq = new Arquivo();
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.println("| Cadastrando Academia:                                                        |");
        System.out.println("+------------------------------------------------------------------------------+");
        Academia tmp;
        String nome, pais, estado, cidade, logradouro, bairro, complemento;
        int numero, classificacao;
        char confirmado = 'n';
        try {
            do {
                System.out.println("Digite o nome da academia: ");
                nome = in.readLine();
                System.out.println("Digite o país: ");
                pais = in.readLine();
                System.out.println("Digite o estado ");
                estado = in.readLine();
                System.out.println("Digite a cidade: ");
                cidade = in.readLine();
                System.out.println("Escreva o logradouro da academia: ");
                logradouro = in.readLine();
                System.out.println("Digite o bairro: ");
                bairro = in.readLine();
                System.out.println("Escreva o número da academia: ");
                numero = Read.nextInt();
                System.out.println("Digite o complemento: ");
                complemento = in.readLine();
                System.out.println("Escreva a classificacao: ");
                classificacao = Read.nextInt();
                System.out.println("Confirma o cadastro: \nDigite 's' para sim \nDigite 'n' para nao");
                confirmado = (char) in.readLine().charAt(0);
                if (confirmado == 'N' || confirmado == 'n') {
                    System.out.println("Deseja refazer o cadastro: \nDigite 's' para sim \nDigite 'n' para nao");
                    confirmado = (char) in.readLine().charAt(0);
                    if (confirmado == 'S' || confirmado == 's') {
                        confirmado = 'n';
                    } else {
                        confirmado = 'q';
                    }
                }
            } while ((confirmado != 's' && confirmado != 'S') || confirmado == 'q');
            if (confirmado == 'S' || confirmado == 's') {
                tmp = new Academia(arq, nome, logradouro, numero, complemento, bairro, cidade, estado, pais, classificacao);
                long endereco = new Arquivo().incluiArq(tmp);
                indiceAcademia.inserir(tmp.getAcademiaID(), endereco);
            }
        } catch (Exception e) {
        }
    }

    /**
     * @Métodos para deletar Métodos que deletam: clientes, Academias e
     * Modalidades
     */
    public static void deletarCliente(Cliente cliente) {
        char confirmado;
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.print("Digite o código do cliente: ");
        int selecionado = Read.nextInt();
        try {
            long endereço = arquivo.pegaporCodigo(cliente, selecionado);
            RandomAccessFile acesso = arquivo.getAccess(cliente);
            if (endereço < 0) {
                System.out.println("Não existe o registro com o código informado!");
                return;
            }
            acesso.seek(endereço);
            cliente.lerObjeto(acesso);
            System.out.println("Tem certeza que deseja apagar: codigo [" + cliente.getClienteID() + "] " + cliente.getNome() + "(s/n)?");
            confirmado = (char) in.readLine().charAt(0);
            if (confirmado == 's' || confirmado == 'S') {
                arquivo.apagaRegistro(indiceCliente, selecionado, cliente);
            }
            acesso.close();
        } catch (IOException ex) {
        } catch (Exception ex) {
            Logger.getLogger(Arquivo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void deletarModalidades(Modalidade modalidade) {
        char confirmado;
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.print("Digite o código do Modalidade: ");
        int selecionado = Read.nextInt();
        try {
            long endereço = arquivo.pegaporCodigo(modalidade, selecionado);

            RandomAccessFile acesso = arquivo.getAccess(modalidade);
            if (endereço < 0) {
                System.out.println("Não existe o registro com o código informado!");
                return;
            }
            acesso.seek(endereço);
            modalidade.lerObjeto(acesso);
            System.out.println("Tem certeza que deseja apagar: codigo [" + modalidade.getModalidadeID() + "] " + modalidade.getNome() + "(s/n)?");
            confirmado = (char) in.readLine().charAt(0);
            if (confirmado == 's' || confirmado == 'S') {
                arquivo.apagaRegistro(indiceModalidade, selecionado, modalidade);
            }
            acesso.close();

        } catch (IOException ex) {
        } catch (Exception ex) {
            Logger.getLogger(Arquivo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void deletarAcademia(Academia academia) {
        char confirmado;
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.print("Digite o código da Academia: ");
        int selecionado = Read.nextInt();
        try {
            long endereço = arquivo.pegaporCodigo(academia, selecionado);

            RandomAccessFile acesso = arquivo.getAccess(academia);
            if (endereço < 0) {
                System.out.println("Não existe o registro com o código informado!");
                return;
            }
            acesso.seek(endereço);
            academia.lerObjeto(acesso);
            System.out.println("Tem certeza que deseja apagar: codigo [" + academia.getAcademiaID() + "] " + academia.getNome() + "(s/n)?");
            confirmado = (char) in.readLine().charAt(0);
            if (confirmado == 's' || confirmado == 'S') {
                arquivo.apagaRegistro(indiceAcademia, selecionado, academia);
            }
            acesso.close();

        } catch (IOException ex) {
        } catch (Exception ex) {
            Logger.getLogger(Arquivo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * @Métodos para editar Métodos que editam: clientes, Academias e
     * Modalidades
     */
    public static void editarCliente(Cliente cliente) {
        Cliente newCliente = cliente;
        System.out.print("Digite o código do cliente que você quer alterar: ");
        int selecionado = Read.nextInt();
        char confirmado = 'n', tSexo = '0';
        try {
            long endereço = arquivo.pegaporCodigo(indiceCliente, selecionado, cliente);
            RandomAccessFile acesso = arquivo.getAccess(cliente);
            if (endereço < 0) {
                System.out.println("Não existe o registro com o código informado!");
                return;
            }
            acesso.seek(endereço);
            cliente.lerObjeto(acesso);
            System.out.println(cliente.toString(cliente));
            System.out.println("\nO que você deseja alterar:");
            System.out.println("Código: 0 --> Nome\nCódigo: 1 --> E-mail\nCódigo: 2 --> Sexo\n"
                    + "Código: 3 --> Login\nCódigo: 4 --> Senha"
                    + "\nCódigo: 5 --> Data de Nascimento\nCódigo: 6 --> Endereço"
                    + "\nCódigo: 7 --> Academia\nCódigo: 8 --> Todos\nCódigo: 9 --> Cancelar"
                    + "\n+------------------------------------------------------------------------------+");
            short operacao = Read.nextShort();
            String newName = "", newEmail = "", newLogin = "", newPassword = "", newLogradouro = "", newComplemento = "", newBairro = "",
                    newCep = "", newCidade = "", newEstado = "", newPais = "";
            long newDate = (0101 * 10000) + 1900;
            int newNumero = 0, newAcademia = 0;
            switch (operacao) {
                case 0:
                    newEmail = cliente.getEmail();
                    newLogin = cliente.getLogin();
                    newPassword = cliente.getSenha();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newDate = cliente.getDataNascimento();
                    newNumero = cliente.getNumeroResidencia();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite o novo nome:");
                    newName = in.readLine();

                    System.out.println("Deseja mesmo alterar o nome do cliente " + selecionado + " de (" + cliente.getNome() + ") para (" + newName + ")? (S/N)");

                    break;
                case 1:
                    newName = cliente.getNome();
                    newLogin = cliente.getLogin();
                    newPassword = cliente.getSenha();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newDate = cliente.getDataNascimento();
                    newNumero = cliente.getNumeroResidencia();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite o novo e-mail:");
                    newEmail = in.readLine();

                    System.out.println("Deseja mesmo alterar o email do cliente " + selecionado + "? (S/N)");

                    break;
                case 2:
                    newName = cliente.getNome();
                    newEmail = cliente.getEmail();
                    newLogin = cliente.getLogin();
                    newPassword = cliente.getSenha();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newDate = cliente.getDataNascimento();
                    newNumero = cliente.getNumeroResidencia();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite novo sexo: (M/F)");
                    tSexo = in.readLine().charAt(0);

                    System.out.println("Deseja mesmo alterar o sexo do cliente " + selecionado + "? (S/N)");

                    break;
                case 3:
                    newName = cliente.getNome();
                    newEmail = cliente.getEmail();
                    newPassword = cliente.getSenha();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newDate = cliente.getDataNascimento();
                    newNumero = cliente.getNumeroResidencia();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite novo login:");
                    newLogin = in.readLine();

                    System.out.println("Deseja alterar o nome do cliente " + selecionado + " de (" + cliente.getLogin() + ") para (" + newLogin + ")? (S/N)");

                    break;
                case 4:
                    newName = cliente.getNome();
                    newEmail = cliente.getEmail();
                    newLogin = cliente.getLogin();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newDate = cliente.getDataNascimento();
                    newNumero = cliente.getNumeroResidencia();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite nova senha:");
                    newPassword = in.readLine();

                    System.out.println("Deseja mesmo alterar a senha do cliente " + selecionado + "? (S/N)");

                    break;
                case 5:
                    newName = cliente.getNome();
                    newEmail = cliente.getEmail();
                    newLogin = cliente.getLogin();
                    newPassword = cliente.getSenha();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newNumero = cliente.getNumeroResidencia();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite nova data de nascimento:");
                    newDate = new Cliente().CalculaData(in.readLine());

                    System.out.println("Deseja alterar a Nascimento do cliente " + selecionado + " de (" + cliente.getDataNascimentoString() + ") para (" + new Cliente().CalculaData(newDate) + ")? (S/N)");

                    break;
                case 6:
                    newName = cliente.getNome();
                    newEmail = cliente.getEmail();
                    newLogin = cliente.getLogin();
                    newPassword = cliente.getSenha();
                    newDate = cliente.getDataNascimento();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    System.out.println("Digite o logradouro: ");
                    newLogradouro = in.readLine();
                    System.out.println("Digite o numero residencial:Ex.:(123)");
                    newNumero = Integer.parseInt(in.readLine());
                    System.out.println("Digite o complemento:");
                    newComplemento = in.readLine();
                    System.out.println("Digite o bairro:");
                    newBairro = in.readLine();
                    System.out.println("Digite o CEP:");
                    newCep = in.readLine();
                    System.out.println("Digite a cidade:");
                    newCidade = in.readLine();
                    System.out.println("Digite o estado:");
                    newEstado = in.readLine();
                    System.out.println("Digite o pais:");
                    newPais = in.readLine();

                    System.out.println("Deseja mesmo alterar o endereço do cliente " + selecionado + "? (S/N)");

                    break;

                case 7:
                    newName = cliente.getNome();
                    newEmail = cliente.getEmail();
                    newLogin = cliente.getLogin();
                    newPassword = cliente.getSenha();
                    newLogradouro = cliente.getLogradouro();
                    newComplemento = cliente.getComplemento();
                    newBairro = cliente.getBairro();
                    newCep = cliente.getCEP();
                    newCidade = cliente.getCidade();
                    newEstado = cliente.getEstado();
                    newPais = cliente.getPais();
                    newNumero = cliente.getNumeroResidencia();
                    tSexo = cliente.getSexo();
                    newAcademia = cliente.getCodAcademia();
                    newDate = cliente.getDataNascimento();
                    System.out.println("Digite o novo codigo da academia:");
                    newAcademia = Integer.parseInt(in.readLine());
                    System.out.println("Deseja mesmo alterar a adademia do cliente " + selecionado + "? (S/N)");

                    break;
                case 8:
                    System.out.println("Digite o novo nome:");
                    newName = in.readLine();
                    System.out.println("Digite o novo e-mail:");
                    newEmail = in.readLine();
                    System.out.println("Digite novo sexo: (M/F)");
                    tSexo = in.readLine().charAt(0);
                    System.out.println("Digite novo login:");
                    newLogin = in.readLine();
                    System.out.println("Digite nova senha:");
                    newPassword = in.readLine();
                    System.out.println("Digite nova data de nascimento:");
                    newDate = new Cliente().CalculaData(in.readLine());
                    System.out.println("Digite o logradouro: ");
                    newLogradouro = in.readLine();
                    System.out.println("Digite o numero residencial:Ex.:(123)");
                    newNumero = Integer.parseInt(in.readLine());
                    System.out.println("Digite o complemento:");
                    newComplemento = in.readLine();
                    System.out.println("Digite o bairro:");
                    newBairro = in.readLine();
                    System.out.println("Digite o CEP:");
                    newCep = in.readLine();
                    System.out.println("Digite a cidade:");
                    newCidade = in.readLine();
                    System.out.println("Digite o estado:");
                    newEstado = in.readLine();
                    System.out.println("Digite o pais:");
                    newPais = in.readLine();
                    System.out.println("Digite o codigo da academia");
                    newAcademia = Integer.parseInt(in.readLine());
                    System.out.println("\n\nDeseja alterar o registro do cliente " + selecionado + "? (S/N)");

                    break;
                case 9:
                    System.out.println("Operação cancelada.\nVoltando ao menu. . .");
                    return;
            }

            confirmado = (char) in.readLine().charAt(0);
            if (confirmado == 's' || confirmado == 'S') {
                arquivo.apagaRegistro(cliente, selecionado);
                newCliente = new Cliente(selecionado, newName, newEmail, tSexo, newLogin, newPassword, newDate, newLogradouro, newNumero, newComplemento, newBairro, newCep, newCidade, newEstado, newPais, newAcademia);
                arquivo.apagaRegistro(indiceCliente, selecionado, cliente);
                long posicao = arquivo.incluiArq(newCliente);
                indiceCliente.atualizar(selecionado, posicao);
            } else {
                System.out.println("Operação cancelada.\nVoltando ao menu. . .");
            }

            newCliente.toString();

            acesso.close();

        } catch (IOException ex) {
        } catch (Exception ex) {
            Logger.getLogger(Arquivo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static void editarModalidades(Modalidade modalidade) {
        Modalidade newModalidade = modalidade;
        char confirmado;
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.print("Digite o código do Modalidade: ");
        int selecionado = Read.nextInt();
        try {
            long endereço = arquivo.pegaporCodigo(modalidade, selecionado);
            RandomAccessFile acesso = arquivo.getAccess(modalidade);
            if (endereço < 0) {
                System.out.println("Não existe o registro com o código informado!");
                return;
            }
            acesso.seek(endereço);
            modalidade.lerObjeto(acesso);
            System.out.println(modalidade.toString());
            System.out.println("\nO que você deseja alterar:");
            System.out.println("Código: 0 --> Nome\nCódigo: 1 --> Descrição\nCódigo: 2 --> Nome do professor\n"
                    + "Código: 3 --> Turno\nCódigo: 4 --> Cancelar"
                    + "\n+------------------------------------------------------------------------------+");
            short operacao = Read.nextShort();
            char newTurno = '-';
            String newNome = "", newDesc = "", newProf = "";
            switch (operacao) {
                case 0:
                    newDesc = modalidade.getDescricao();
                    newProf = modalidade.getNomeProfessor();
                    newTurno = modalidade.getTurno();
                    System.out.println("Digite novo nome: ");
                    newNome = in.readLine();

                    System.out.println("Deseja mesmo alterar o nome da modalidade "
                            + "[" + modalidade.getModalidadeID() + "] de (" + modalidade.getNome() + ") para (" + newNome + ")? (S/N)");

                    break;
                case 1:
                    newNome = modalidade.getNome();
                    newProf = modalidade.getNomeProfessor();
                    newTurno = modalidade.getTurno();
                    System.out.println("Digite nova descrição: ");
                    newDesc = in.readLine();

                    System.out.println("Deseja mesmo alterar a descrição da modalidade "
                            + "[" + modalidade.getModalidadeID() + "] " + modalidade.getNome() + "? (S/N)");

                    break;
                case 2:
                    newNome = modalidade.getNome();
                    newDesc = modalidade.getDescricao();
                    newTurno = modalidade.getTurno();
                    System.out.println("Digite novo nome do professor: ");
                    newProf = in.readLine();

                    System.out.println("Deseja mesmo alterar o nome do professor da modalidade "
                            + "[" + modalidade.getModalidadeID() + "] " + modalidade.getNome() + " de "
                            + "(" + modalidade.getNomeProfessor() + ") para (" + newProf + ")? (S/N)");

                    break;
                case 3:
                    newNome = modalidade.getNome();
                    newDesc = modalidade.getDescricao();
                    newProf = modalidade.getNomeProfessor();
                    boolean valido = false;
                    while (!valido) {
                        System.out.println("Digite novo turno: (M/T/N)");
                        newTurno = in.readLine().charAt(0);
                        if (newTurno != 'M' || newTurno != 'T' || newTurno != 'N') {
                            System.out.println("Turno selecionado invalido. "
                                    + "\nFavor escolher dentre as opções M(Manhã), T(Tarde) ou N(Noite).");
                        } else {
                            valido = true;
                        }
                    }

                    System.out.println("Deseja mesmo alterar o turno da modalidade "
                            + "[" + modalidade.getModalidadeID() + "] " + modalidade.getNome() + "? (S/N)");

                    break;
                case 4:
                    System.out.println("Operação cancelada.\nVoltando ao Menu. . .");
                    return;
            }

            confirmado = (char) in.readLine().charAt(0);
            if (confirmado == 's' || confirmado == 'S') {
                arquivo.apagaRegistro(modalidade, selecionado);
                newModalidade = new Modalidade(selecionado, newNome, newDesc, newProf, newTurno);
                arquivo.apagaRegistro(indiceCliente, selecionado, modalidade);
                long posicao = arquivo.incluiArq(newModalidade);
                indiceCliente.atualizar(selecionado, posicao);
            } else {
                System.out.println("Operação cancelada.\nVoltando ao Menu. . .");
            }

            acesso.close();

        } catch (IOException ex) {
        } catch (Exception ex) {
            Logger.getLogger(Arquivo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void editarAcademia(Academia academia) {
        Academia newAcademia = academia;
        char confirmado;
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.print("Digite o código da Academia: ");
        int selecionado = Read.nextInt();
        try {
            long endereço = arquivo.pegaporCodigo(academia, selecionado);

            RandomAccessFile acesso = arquivo.getAccess(academia);
            if (endereço < 0) {
                System.out.println("Não existe o registro com o código informado!");
                return;
            }
            acesso.seek(endereço);
            academia.lerObjeto(acesso);
            System.out.println(academia.toString());
            System.out.println("\nO que você deseja alterar:");
            System.out.println("Código: 0 --> Nome\nCódigo: 1 --> Endereço\nCódigo: 2 --> Cancelar"
                    + "\n+------------------------------------------------------------------------------+");
            short operacao = Read.nextShort();
            String newNome = "", newLog = "", newCompl = "", newBairro = "", newCidade = "", newEstado = "", newPais = "";
            int newNumero = 123;
            switch (operacao) {
                case 0:
                    newPais = academia.getPais();
                    newEstado = academia.getEstado();
                    newCidade = academia.getCidade();
                    newLog = academia.getLogradouro();
                    newBairro = academia.getBairro();
                    newNumero = academia.getNumeroAcademia();
                    newCompl = academia.getComplemento();
                    System.out.println("Digite novo nome: ");
                    newNome = in.readLine();

                    System.out.println("Deseja mesmo alterar o nome da academia "
                            + "[" + academia.getAcademiaID() + "] de (" + academia.getNome() + ") para (" + newNome + ")? (S/N)");

                    break;
                case 1:
                    newNome = academia.getNome();
                    System.out.println("Digite o país: ");
                    newPais = in.readLine();
                    System.out.println("Digite o estado ");
                    newEstado = in.readLine();
                    System.out.println("Digite a cidade: ");
                    newCidade = in.readLine();
                    System.out.println("Escreva o logradouro da academia: ");
                    newLog = in.readLine();
                    System.out.println("Digite o bairro: ");
                    newBairro = in.readLine();
                    System.out.println("Escreva o número da academia: ");
                    newNumero = Read.nextInt();
                    System.out.println("Digite o complemento: ");
                    newCompl = in.readLine();

                    System.out.println("Deseja mesmo alterar o endereço da academia "
                            + "[" + academia.getAcademiaID() + "] " + academia.getNome() + "? (S/N)");

                    break;
                case 2:
                    System.out.println("Operação cancelada.\nVoltando ao Menu. . .");
                    return;
            }

            confirmado = (char) in.readLine().charAt(0);
            if (confirmado == 's' || confirmado == 'S') {
                arquivo.apagaRegistro(academia, selecionado);
                newAcademia = new Academia(selecionado, newNome, newLog, newNumero, newCompl, newBairro, newCidade, newEstado, newPais, newNumero);
                arquivo.apagaRegistro(indiceCliente, selecionado, academia);
                long posicao = arquivo.incluiArq(newAcademia);
                indiceCliente.atualizar(selecionado, posicao);
            } else {
                System.out.println("Operação cancelada.\nVoltando ao Menu. . .");
            }

            acesso.close();

        } catch (IOException ex) {
        } catch (Exception ex) {
            Logger.getLogger(Arquivo.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * @Método para pesquisar Métodos generico que pesquisa: clientes, Academias
     * e Modalidades por meio de uma chave escolhida
     */
    public static void pesquisa() {
        int[] array = new int[0];
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.println("| Realizando pesquisa                                                          |");
        System.out.println("+------------------------------------------------------------------------------+");
        System.out.println("Opções:\n "
                + "|0 -> Cancelar                                         |"
                + "\n |1 -> Cliente que frequentam a academia<chave>         |"
                + "\n |2 -> Modalidades  de uma certa Academia<chave>        |"
                + "\n |3 -> Academias que apresentam esta modalidade<chave>  |");
        System.out.print("Digite a operação: ");
        int operacao = Read.nextInt();
        switch (operacao) {
            case 0:
                System.out.print("Pesquisa Cancelada!!!");
                break;
            case 1:
                System.out.print("Digite o código da academia: ");
                operacao = Read.nextInt();
                 {
                    try {
                        array = indiceAcademiaCliente.lista(operacao);
                    } catch (IOException ex) {
                        Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                for (int i = 0; i < array.length; i++) {
                    arquivo.listarPorCOD_1N(indiceCliente, array[i], new Cliente());
                }
                break;
            case 2:
                System.out.print("Digite o código da academia: ");
                operacao = Read.nextInt();
                {
                    try {
                        array = indiceAcademiaModalidade.lista(operacao);
                    } catch (IOException ex) {
                        Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                for (int i = 0; i < array.length; i++) {
                    arquivo.listarPorCOD_1N(indiceModalidade, array[i], new Modalidade());
                }
                break;
            case 3:
                System.out.print("Digite o código da Modalidade: ");
                operacao = Read.nextInt();
                {
                    try {
                        array = indiceModalidadeAcademia.lista(operacao);
                    } catch (IOException ex) {
                        Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                for (int i = 0; i < array.length; i++) {
                    arquivo.listarPorCOD_1N(indiceAcademia, array[i], new Academia());
                }
                break;
        }
    }

    public static void vincular() {
        if (arquivo.getQuantidade(new Academia()) == 0 || arquivo.getQuantidade(new Modalidade()) == 0) {
            System.out.println("O campo de academia ou modalidade está zerado, por favor preencha ele antes!");
            return;
        }
        System.out.println("Digite o codigo da academia que deseja vincular a modalidade: ");
        int codAcademia = Read.nextInt();
        System.out.println("Digite o codigo da modalidade que deseja vincular a academia: ");
        int codModalidade = Read.nextInt();
        try {
            indiceAcademiaModalidade.inserir(codAcademia, codModalidade);
            indiceModalidadeAcademia.inserir(codModalidade, codAcademia);
        } catch (IOException ex) {
            Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void desvincular() {
        System.out.println("Digite o codigo da academia que deseja desvincular a modalidade: ");
        int codAcademia = Read.nextInt();
        System.out.println("Digite o codigo da modalidade que deseja desvincular a academia: ");
        int codModalidade = Read.nextInt();
        try {
            indiceAcademiaModalidade.excluir(codAcademia, codModalidade);
            indiceModalidadeAcademia.excluir(codModalidade, codAcademia);
        } catch (IOException ex) {
            Logger.getLogger(Interface.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
