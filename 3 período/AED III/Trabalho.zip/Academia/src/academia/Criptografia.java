package academia;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
public class Criptografia
{
	Cipher cifra;
	private SecretKeySpec key;
	byte [ ] cifrado;
	byte [ ] decifrado;
	private byte [ ] chave;
	private String stringchave = "PROJETOPROJETOPR"; // a chave tem que ter 128 bits (16 bytes = 16 caracteres ASCII)
	public Criptografia ( ) throws Exception
	{
		chave = stringchave.getBytes();
		cifra = Cipher.getInstance("AES/ECB/PKCS5PADDING");
		key = new SecretKeySpec(chave,"AES");
	}

	public byte [ ] cifrar (byte [ ] b) throws Exception
	{
		cifra.init(Cipher.ENCRYPT_MODE,key);
		cifrado = cifra.doFinal(b);
		return ( cifrado );
	}

	public byte [ ] decifrar (byte [ ] b) throws Exception
	{
		cifra.init(Cipher.DECRYPT_MODE,key);
		decifrado = cifra.doFinal(b);
		return ( decifrado );
	}
}