import 'package:flutter/material.dart';
import 'package:uatu/MainScreen.dart';
import 'package:uatu/CreateAccountScreen.dart';
import 'Vigilante.dart';

class LoginScreen extends StatelessWidget {
  static TextEditingController login = TextEditingController();
  static TextEditingController password = TextEditingController();
  static final failedLoginMessage = SnackBar(content: Text('Invalid Data'));

  static void validateLogin(BuildContext context) {
    if (login.text == Vigilante.example().login && password.text == Vigilante.example().senha) {
      Navigator.push(context, MaterialPageRoute(builder: (context) => MainScreen()));
      login.text = "";
      password.text = "";
    }
    else {
      Scaffold.of(context).showSnackBar(failedLoginMessage);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Uatu'),),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Builder(
          builder: (BuildContext context) {
          return ListView(
            //mainAxisAlignment: MainAxisAlignment.start,

            children: <Widget>[
              Image.asset('assets/uatu.jpg'),
              TextField(decoration: InputDecoration(hintText: 'Login'), controller: login),
              TextField(decoration: InputDecoration(hintText: 'Senha'), obscureText: true, controller: password),
              RaisedButton(child: Text('Login'), onPressed: () {validateLogin(context);}),
              RaisedButton(child: Text('Cadastrar'), onPressed: () {Navigator.push(context, MaterialPageRoute(builder: (context) => CreateAccountScreen()));})
            ],
          );}
        ),
      ),
    );
  }
}