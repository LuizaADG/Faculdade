import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'LoginScreen.dart';
import 'Post.dart';
import 'Vigilante.dart';
import 'DetailedPostScreen.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(title: 'Uatu', theme: ThemeData(primarySwatch: Colors.deepPurple), home: LoginScreen());
  }
}

class MainScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => MainScreenState(Vigilante.example());
}

class MainScreenState extends State<MainScreen> {
  static Vigilante loggedVigilante;
  Future<File> imageFile;

  MainScreenState(Vigilante vigilante) {loggedVigilante = vigilante;}

  void pickImageFromGallery(ImageSource source) {
    setState(() {
      imageFile = ImagePicker.pickImage(source: source);
    });
  }

  // Function to show images on the create new post tab
  Widget showImage() {
    return FutureBuilder<File>(
      future: imageFile,
      builder: (BuildContext context, AsyncSnapshot<File> snapshot) {
        if (snapshot.connectionState == ConnectionState.done && snapshot.data != null) {
          Post.newPostImage = Image.file(snapshot.data, width: 300, height: 200);
          return Image.file(snapshot.data, width: 300, height: 200);
        }
        else if (snapshot.error != null) {
          return const Text('Error Picking Image', textAlign: TextAlign.center);
        }
        else {
          return Image(image: AssetImage('assets/placeholder.jpg'), width: 300,height: 200);
        }
      },
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
        length: 3,
        child: Scaffold(
            appBar: AppBar(
              title: Text('Uatu'),
              bottom: TabBar(tabs: <Widget>[Tab(icon: Icon(Icons.create)), Tab(icon: Icon(Icons.list)), Tab(icon: Icon(Icons.account_circle))]),
            ),
            body: TabBarView(children: [
              // New Post Tab
              Container(
                  child: Padding(
                    padding: EdgeInsets.all(8),
                    child: ListView(
                      //mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        InkWell(child: showImage(), onTap: () {pickImageFromGallery(ImageSource.gallery);}),
                        TextField(decoration: InputDecoration(hintText: 'Título:'), controller: Post.newPostTitle,),
                        TextField(decoration: InputDecoration(hintText: 'Detalhes:\n\n\n\nNos diga o que está acontecendo'), controller: Post.newPostDescription, maxLines: 8, minLines: 5),
                        RatingsWidget(),
                        Builder(
                          builder: (BuildContext context) {return RaisedButton(child: Text('Fazer postagem'), onPressed: () {
                            setState(() {
                              DefaultTabController.of(context).animateTo(1);
                              loggedVigilante.addPost(Post.fromUI());
                            });
                          });},
                        )
                      ],
                    ),
                  )
              ),

              // Post History Tab
              ListView.builder(
                padding: EdgeInsets.all(8),
                itemCount: loggedVigilante.postHistory.length,
                itemBuilder: (BuildContext context, int index) {
                  return InkWell(child: Post.toCard(loggedVigilante.postHistory[index]), onTap: () {
                    DetailedPostScreen.currentPost = loggedVigilante.postHistory[index];
                    Navigator.push(context, MaterialPageRoute(builder: (context) => DetailedPostScreen()));
                  });
                },
              ),

              //Profile Tab
              Container(
                  padding: EdgeInsets.all(8),
                  child: ListView(children: <Widget>[
                    Row(children: <Widget>[
                      Image(image: AssetImage('assets/Seu_Madruga.jpg'), width: 130, height: 130,),
                      Flexible(child: Column(children: <Widget>[
                        TextField(decoration: InputDecoration(hintText: 'Nome:'), controller: Vigilante.vigilanteNewName),
                        TextField(decoration: InputDecoration(hintText: 'Agência:'), controller: Vigilante.vigilanteNewAgencia),
                        TextField(decoration: InputDecoration(hintText: 'Conta:'), controller: Vigilante.vigilanteNewConta)
                      ]))
                    ]),
                    TextField(decoration: InputDecoration(hintText: 'E-mail:'), controller: Vigilante.vigilanteNewEmail),
                    TextField(decoration: InputDecoration(hintText: 'Bio:\n\n\n\nConte um pouco sobre você aqui'), maxLines: 8, minLines: 5, controller: Vigilante.vigilanteNewBio),
                    RaisedButton(child: Text('Salvar Alterações'), onPressed: (){})
                  ])
              )

            ])
        )
    );
  }

}

class RatingsWidget extends StatefulWidget {
  @override
  RatingsWidgetState createState() => RatingsWidgetState();
}

class RatingsWidgetState extends State<RatingsWidget> {
  static int rating = 1;

  @override
  Widget build(BuildContext context) {
    List<Widget> array = [];
    var filled = Colors.blue;
    var empty = Colors.black;
    for (var i = 1; i <= 5; i++) {
      array.add(IconButton(
        icon: Icon(Icons.star),
        color: (rating < i ? empty : filled),
        onPressed: () {
          setState(() {
            Post.newPostRating = i;
            rating = i;
          });
        },
      ));
    }
    return Row(
      children: array,
      mainAxisAlignment: MainAxisAlignment.center,
    );
  }
}