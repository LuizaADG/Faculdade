import 'package:flutter/material.dart';

class CreateAccountScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(decoration: InputDecoration(hintText: 'Nome')),
            TextField(decoration: InputDecoration(hintText: 'E-mail')),
            TextField(decoration: InputDecoration(hintText: 'Telefone')),
            TextField(decoration: InputDecoration(hintText: 'Conta')),
            TextField(decoration: InputDecoration(hintText: 'Agência')),
            TextField(decoration: InputDecoration(hintText: 'Senha'), obscureText: true),
            TextField(decoration: InputDecoration(hintText: 'Confirmar Senha'), obscureText: true),
            RaisedButton(child: Text('Cadastrar'), onPressed: () {Navigator.pop(context);}, color: Colors.indigoAccent,)
          ],
        )
    );
  }
}