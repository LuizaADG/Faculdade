import 'package:flutter/material.dart';

import 'Post.dart';

class Vigilante {
  int id;
  String nome;
  String email;
  String agencia;
  String conta;
  double saldo;
  String bio;
  String login;
  String senha;
  List<Post> postHistory;

  // Variables to hold the data from the screen until the profile is updated
  static TextEditingController vigilanteNewName = TextEditingController();
  static TextEditingController vigilanteNewAgencia = TextEditingController();
  static TextEditingController vigilanteNewConta = TextEditingController();
  static TextEditingController vigilanteNewEmail = TextEditingController();
  static TextEditingController vigilanteNewBio = TextEditingController();


  Vigilante(String nome, String email, String agencia, String conta, String login, String senha) {
    this.nome = nome;
    this.email = email;
    this.agencia = agencia;
    this.conta = conta;
    this.login = login;
    this.senha = senha;
  }

  static Vigilante example() {
    Vigilante example = new Vigilante('Seu Madruga', 'seumadruga@vila.com', '1022', '1187468', 'admin', 'admin');
    example.postHistory = Post.examplePosts();
    example.saldo = 2.5;
    return example;
  }

  void addPost(Post post) {this.postHistory.insert(0, post);}

  // Updates profile based on what is currently on the UI
  void atualizarPerfil() {
    this.nome = vigilanteNewName.text;
    this.agencia = vigilanteNewAgencia.text;
    this.conta = vigilanteNewConta.text;
    this.email = vigilanteNewEmail.text;
    this.bio = vigilanteNewBio.text;
  }

  // Wraps vigilante to be saved in database
  Map<String, dynamic> toMap() {
    var map = Map<String, dynamic>();

    map['id'] = id;
    map['nome'] = nome;
    map['email'] = email;
    map['agencia'] = agencia;
    map['conta'] = conta;
    map['saldo'] = saldo;
    map['bio'] = bio;
    map['login'] = login;
    map['senha'] = senha;

    return map;
  }

  // Converts data from database to object
  Vigilante.fromMapObject(Map<String, dynamic> map) {
    this.id = map['id'];
    this.nome = map['nome'];
    this.email = map['email'];
    this.agencia = map['agencia'];
    this.conta = map['conta'];
    this.saldo = map['saldo'];
    this.bio = map['bio'];
    this.login = map['login'];
    this.senha = map['senha'];
  }
}