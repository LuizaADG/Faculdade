import 'package:flutter/material.dart';
import 'Post.dart';

class DetailedPostScreen extends StatelessWidget {
  static Post currentPost;

  void setCurrentPost(Post post) {
    currentPost = post;
    RatingsDisplayState.rating = post.rating;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Uatu')),
      body: Container(
          child: Padding(
            padding: EdgeInsets.all(8),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                currentPost.image,
                Text(currentPost.title),
                Text(currentPost.description),
                RatingsDisplay(),
              ],
            ),
          )
      ),
    );
  }
}

class RatingsDisplay extends StatefulWidget {
  @override
  RatingsDisplayState createState() => RatingsDisplayState();
}

class RatingsDisplayState extends State<RatingsDisplay> {
  static int rating = 1;

  @override
  Widget build(BuildContext context) {
    setState(() {
      rating = DetailedPostScreen.currentPost.rating;
    });

    List<Widget> array = [];
    var filled = Colors.blue;
    var empty = Colors.black;
    for (var i = 1; i <= 5; i++) {
      array.add(IconButton(
        icon: Icon(Icons.star),
        color: (rating < i ? empty : filled),
      ));
    }
    return Row(
      children: array,
      mainAxisAlignment: MainAxisAlignment.center,
    );
  }
}