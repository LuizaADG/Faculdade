import 'dart:io';

import 'package:flutter/material.dart';

class Post {
  String title;
  String description;
  Image image;
  Future<File> imageFile;
  int rating;
  Icon icon;

  // Choose from these when instatiating a post object
  static final Icon acceptedIcon = Icon(Icons.check, color: Colors.green);
  static final Icon processingIcon = Icon(Icons.remove_circle_outline, color: Colors.yellow);
  static final Icon rejectedIcon = Icon(Icons.clear, color: Colors.red);

  // Variables to hold the data from the screen until a new post is created
  // These are used in conjunction with the fromUI constructor
  static TextEditingController newPostTitle = TextEditingController();
  static TextEditingController newPostDescription = TextEditingController();
  static int newPostRating = -1;
  static Image newPostImage;

  // Default constructor
  Post(String title, String description, String image, Icon icon, int rating) {
    this.title = title;
    this.description = description;
    this.image = Image(image: AssetImage(image), width: 480, height: 360);
    this.icon = icon;
    this.rating = rating;
  }

  // Constructor to create a post using data from the UI. Cleans UI when is used
  Post.fromUI() {
    this.title = newPostTitle.text;
    this.description = newPostDescription.text;
    this.image = newPostImage;
    this.icon = processingIcon;
    this.rating = newPostRating;

    newPostTitle.text = "";
    newPostDescription.text = "";
    // TODO: Figure out a way to clean image and rating
  }

  static Widget toCard(Post post) {
    Card card = Card(child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              ListTile(leading: post.icon, title: Text(post.title), subtitle: Text(post.description)),
              ButtonTheme.bar(
                child: ButtonBar(
                  children: <Widget>[
                    FlatButton(
                      child: const Text('SHARE'),
                      onPressed: () { /* ... */ },
                    ),
                    FlatButton(
                      child: const Text('DISMISS'),
                      onPressed: () { /* ... */ },
                    ),
                  ],
                ),
              ),
            ],
      ),
    );
    return card;
  }

  static List<Post> examplePosts() {
    Post post = Post('Buraco na rodovia', 'Na Rua Tal esquina com a Outra, há um...\n...e aí teve...\n...voou janela afora e...\n...com um desentupidor de pia.', 'assets/pothole.jpg', processingIcon, 2);
    Post post1 = Post('Residência abandonada', 'A residência abandonada no lugar Tal está servindo como...\n...desde que aquele cachorro resolveu...\n...três de um lado e cinco do outro, aí...\n...isso sem contar o vaso de petúnias.', 'assets/abandonedHouse.jpg', acceptedIcon, 4);
    Post post2 = Post('Ruído excessivo vindo do Lugar Chato', 'O famoso Lugar Chato, que fica aberto até...\n...de uma cor engraçada, meio bonina, meio gelo. Mas também...\n...blablaBla? - Bla! - ele respondeu pro outro, que...\n...permitido por lei, mas apenas nas terças.', 'assets/rave.png', rejectedIcon, 1);

    return [post, post1, post2];
  }

}