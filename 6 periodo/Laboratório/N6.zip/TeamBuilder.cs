﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;

public class TeamBuilder : MonoBehaviour
{
    private void OnEnable()
    {
        gameObject.GetComponent<BoardManager>().enabled = false;
        gameObject.GetComponent<TeamPlacer>().enabled = false;
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = true;
    }
    bool isWhiteStandardTeam;
    bool isBlackStandardTeam;

    float whiteQueens = 0;
    float whiteKnights = 0;
    float whiteBishops = 0;
    float whiteRooks = 0;
    float whitePawns = 0;

    float blackQueens = 0;
    float blackKnights = 0;
    float blackBishops = 0;
    float blackRooks = 0;
    float blackPawns = 0;

    float initialPoints = 2700;

    float currentWhitePoints = 2700;
    float currentBlackPoints = 2700;

    public static int[] WhiteTeam = new int[5];
    public static int[] BlackTeam = new int[5];


    public void WhiteStandardTeam(bool toggle)
    {
        isWhiteStandardTeam = toggle;

        if (isWhiteStandardTeam)
        {
            GameObject.Find("WhiteQueenSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("WhiteKnightSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("WhiteBishopSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("WhiteRookSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("WhitePawnSlider").GetComponent<Slider>().interactable = false;

            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }

        else
        {
            GameObject.Find("WhiteQueenSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("WhiteKnightSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("WhiteBishopSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("WhiteRookSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("WhitePawnSlider").GetComponent<Slider>().interactable = true;

            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }
    }

    public void BlackStandardTeam(bool toggle)
    {
        isBlackStandardTeam = toggle;

        if (isBlackStandardTeam)
        {
            GameObject.Find("BlackQueenSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("BlackKnightSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("BlackBishopSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("BlackRookSlider").GetComponent<Slider>().interactable = false;
            GameObject.Find("BlackPawnSlider").GetComponent<Slider>().interactable = false;

            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }

        else
        {
            GameObject.Find("BlackQueenSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("BlackKnightSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("BlackBishopSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("BlackRookSlider").GetComponent<Slider>().interactable = true;
            GameObject.Find("BlackPawnSlider").GetComponent<Slider>().interactable = true;

            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }
    }


    private bool WhiteMaxPieces()
    {
        if (GameObject.Find("WhiteQueenSlider").GetComponent<Slider>().value + GameObject.Find("WhiteBishopSlider").GetComponent<Slider>().value +
                              GameObject.Find("WhiteRookSlider").GetComponent<Slider>().value + GameObject.Find("WhitePawnSlider").GetComponent<Slider>().value +
                              GameObject.Find("WhiteKnightSlider").GetComponent<Slider>().value > 15)
            return true;

        else
            return false;
    }

    private bool BlackMaxPieces()
    {
        if (GameObject.Find("BlackQueenSlider").GetComponent<Slider>().value + GameObject.Find("BlackBishopSlider").GetComponent<Slider>().value +
                              GameObject.Find("BlackRookSlider").GetComponent<Slider>().value + GameObject.Find("BlackPawnSlider").GetComponent<Slider>().value +
                              GameObject.Find("BlackKnightSlider").GetComponent<Slider>().value > 15)
            return true;

        else
            return false;
    }


    public void WhiteQueens(float SetValue)
    {
        whiteQueens = SetValue;
        WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);

        if (currentWhitePoints < 0 || WhiteMaxPieces())
        {
            GameObject.Find("WhiteQueenSlider").GetComponent<Slider>().value--;
            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }
    }

    public void WhiteKnights(float SetValue)
    {
        whiteKnights = SetValue;
        WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);

        if (currentWhitePoints < 0 || WhiteMaxPieces())
        {
            GameObject.Find("WhiteKnightSlider").GetComponent<Slider>().value--;
            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }
    }

    public void WhiteBishops(float SetValue)
    {
        whiteBishops = SetValue;
        WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);

        if (currentWhitePoints < 0 || WhiteMaxPieces())
        {
            GameObject.Find("WhiteBishopSlider").GetComponent<Slider>().value--;
            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }
    }

    public void WhiteRooks(float SetValue)
    {
        whiteRooks = SetValue;
        WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);

        if (currentWhitePoints < 0 || WhiteMaxPieces())
        {
            GameObject.Find("WhiteRookSlider").GetComponent<Slider>().value--;
            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }
    }

    public void WhitePawns(float SetValue)
    {
        whitePawns = SetValue;
        WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);

        if (currentWhitePoints < 0 || WhiteMaxPieces())
        {
            GameObject.Find("WhitePawnSlider").GetComponent<Slider>().value--;
            WhitePoints(isWhiteStandardTeam, whiteQueens, whiteKnights, whiteBishops, whiteRooks, whitePawns);
        }
    }


    public void BlackPawns(float SetValue)
    {
        blackPawns = SetValue;
        BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);

        if (currentBlackPoints < 0 || BlackMaxPieces())
        {
            GameObject.Find("BlackPawnSlider").GetComponent<Slider>().value--;
            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }
    }

    public void BlackRooks(float SetValue)
    {
        blackRooks = SetValue;
        BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);

        if (currentBlackPoints < 0 || BlackMaxPieces())
        {
            GameObject.Find("BlackRookSlider").GetComponent<Slider>().value--;
            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }
    }

    public void BlackBishops(float SetValue)
    {
        blackBishops = SetValue;
        BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);

        if (currentBlackPoints < 0 || BlackMaxPieces())
        {
            GameObject.Find("BlackBishopSlider").GetComponent<Slider>().value--;
            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }
    }

    public void BlackKnights(float SetValue)
    {
        blackKnights = SetValue;
        BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);

        if (currentBlackPoints < 0 || BlackMaxPieces())
        {
            GameObject.Find("BlackKnightSlider").GetComponent<Slider>().value--;
            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }
    }

    public void BlackQueens(float SetValue)
    {
        blackQueens = SetValue;
        BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);

        if (currentBlackPoints < 0 || BlackMaxPieces())
        {
            GameObject.Find("BlackQueenSlider").GetComponent<Slider>().value--;
            BlackPoints(isBlackStandardTeam, blackQueens, blackKnights, blackBishops, blackRooks, blackPawns);
        }
    }


    public void WhitePoints(bool isWhiteStandardTeam, float whiteQueens, float whiteKnights, float whiteBishops, float whiteRooks, float whitePawns)
    {
        if (isWhiteStandardTeam)
            currentWhitePoints = 0;
        else
            currentWhitePoints = initialPoints - (500 * whiteQueens) - (300 * whiteKnights) - (200 * whiteBishops) - (200 * whiteRooks) - (100 * whitePawns);

        GameObject.Find("WhiteTeamPoints").GetComponent<Text>().text = currentWhitePoints.ToString();
    }

    public void BlackPoints(bool isBlackStandardTeam, float blackQueens, float blackKnights, float blackBishops, float blackRooks, float blackPawns)
    {
        if (isBlackStandardTeam)
            currentBlackPoints = 0;
        else
            currentBlackPoints = initialPoints - (500 * blackQueens) - (300 * blackKnights) - (200 * blackBishops) - (200 * blackRooks) - (100 * blackPawns);

        GameObject.Find("BlackTeamPoints").GetComponent<Text>().text = currentBlackPoints.ToString();
    }

    public void StartGame()
    {
        if (isWhiteStandardTeam)
        {
            WhiteTeam[0] = 1;
            WhiteTeam[1] = 2;
            WhiteTeam[2] = 2;
            WhiteTeam[3] = 2;
            WhiteTeam[4] = 8;
        }

        else
        {
            WhiteTeam[0] = System.Convert.ToInt32(whiteQueens);
            WhiteTeam[1] = System.Convert.ToInt32(whiteKnights);
            WhiteTeam[2] = System.Convert.ToInt32(whiteBishops);
            WhiteTeam[3] = System.Convert.ToInt32(whiteRooks);
            WhiteTeam[4] = System.Convert.ToInt32(whitePawns);
        }

        if (isBlackStandardTeam)
        {
            BlackTeam[0] = 1;
            BlackTeam[1] = 2;
            BlackTeam[2] = 2;
            BlackTeam[3] = 2;
            BlackTeam[4] = 8;
        }

        else
        {
            BlackTeam[0] = System.Convert.ToInt32(blackQueens);
            BlackTeam[1] = System.Convert.ToInt32(blackKnights);
            BlackTeam[2] = System.Convert.ToInt32(blackBishops);
            BlackTeam[3] = System.Convert.ToInt32(blackRooks);
            BlackTeam[4] = System.Convert.ToInt32(blackPawns);
        }
        gameObject.GetComponent<TeamPlacer>().enabled = true;
        GameObject.Find("Canvas").GetComponent<Canvas>().enabled = false;
    }
}

